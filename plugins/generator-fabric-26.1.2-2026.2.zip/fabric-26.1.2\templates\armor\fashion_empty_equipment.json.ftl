{
  "layers": {
    "humanoid": [],
    "humanoid_leggings": []
  }
}
